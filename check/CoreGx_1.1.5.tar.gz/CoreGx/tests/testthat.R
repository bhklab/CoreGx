library(testthat)
library(CoreGx)

test_check("CoreGx")
