# ==== LongTable Class

## TODO:: Implement intersection of LongTable objects