# Define global variables for data.table functions
utils::globalVariables(c('..idCols', 'rowKey', 'colKey', 'capture.output',
    'filePath', '..cols', 'head', 'tail', 'sharedIDCols'))