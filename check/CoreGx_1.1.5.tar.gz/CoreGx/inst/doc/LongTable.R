## ----setup, include=FALSE-----------------------------------------------------
library(formatR)
knitr::opts_chunk$set(echo = FALSE)

## ----dependencies, include=FALSE----------------------------------------------
library(CoreGx)
library(data.table)

## ----class_diagram, fig.wide=TRUE, caption='LongTable Class Diagram'----------
knitr::include_graphics('LongTableClassDiagram.png')

## ----long_table_structure, fig.wide=TRUE, caption='LongTable Structure'-------
knitr::include_graphics('LongTableStructure.png')

## ----head_data, echo=TRUE-----------------------------------------------------

filePath <- '../data/merckLongTable.csv'
merckDT <- fread(filePath, na.strings=c('NULL'))
colnames(merckDT)

## ----sample_data, fig.width=80, echo=TRUE-------------------------------------
knitr::kable(head(merckDT)[, 1:5])

## ----sample_data2, fig.width=80, echo=TRUE------------------------------------
knitr::kable(head(merckDT)[, 5:ncol(merckDT)])

## ----build_from_single_table_file, echo=TRUE----------------------------------
rowDataCols <- list(
    c(cell_line1="cell_line", BatchID="BatchID"))
colDataCols <- list(
    c(drug1='drugA_name', drug2='drugB_name',
     drug1dose='drugA Conc (µM)', drug2dose='drugB Conc (µM)'),
    c(comboName='combination_name'))
assayCols <- list(viability=paste0('viability', seq_len(4)),
                  viability_summary=c('mu/muMax', 'X/X0'))
longTable <- buildLongTable(from=filePath, rowDataCols,
                            colDataCols, assayCols)

## ----show_method--------------------------------------------------------------
longTable

## ----from_single_table, eche=TRUE---------------------------------------------
longTable1 <- buildLongTable(from=merckDT, rowDataCols, colDataCols, assayCols)

paste0('All equal? ', all.equal(longTable, longTable1))

## ----from_list_of_tables, echo=TRUE-------------------------------------------
assayList <- assays(longTable, withDimnames=TRUE, metadata=TRUE, key=FALSE)
assayList$new_viability <- assayList$viability  # Add a fake additional assay
assayCols$new_viability <-  assayCols$viability  # Add column names for fake assay
longTable2 <- buildLongTable(from=assayList, lapply(rowDataCols, names), lapply(colDataCols, names), assayCols)

## ----show_method2-------------------------------------------------------------
longTable2

## ----rownames, echo=TRUE------------------------------------------------------
head(rownames(longTable))

## ----colnames, echo=TRUE------------------------------------------------------
head(colnames(longTable))

## ----subset_dataframe_character, echo=TRUE------------------------------------
row <- rownames(longTable)[1]
columns <- colnames(longTable)[1:2]
longTable[row, columns]

## ----rowdata_coldata, echo=TRUE-----------------------------------------------
head(rowData(longTable), 3)
head(colData(longTable), 3)

## ----simple_regex, echo=TRUE--------------------------------------------------
longTable[, '5-FU']

## ----column_specific_regex, echo=TRUE-----------------------------------------
all.equal(longTable[, '5-FU:*:*:*'], longTable[, '^5-FU'])

## ---- echo=TRUE---------------------------------------------------------------
longTable[.(cell_line1 == 'CAOV3'),  # row query
          .(drug1 == 'Temozolomide' & drug2 %in% c('Lapatinib', 'Bortezomib'))]  # column query

## ----echo=TRUE----------------------------------------------------------------
subLongTable <-
  longTable[.(BatchID != 2),
            .(drug1 == 'Temozolomide' & drug2 != 'Lapatinib')]

## ----echo=TRUE----------------------------------------------------------------
print(paste0('BatchID: ', paste0(unique(rowData(subLongTable)$BatchID), collapse=', ')))
print(paste0('drug2: ', paste0(unique(colData(subLongTable)$drug2), collapse=', ')))

## ----echo=TRUE----------------------------------------------------------------
head(rowData(longTable), 3)

## ----echo=TRUE----------------------------------------------------------------
head(rowData(longTable, key=TRUE), 3)

## ----echo=TRUE----------------------------------------------------------------
head(colData(longTable), 3)

## ----echo=TRUE----------------------------------------------------------------
head(colData(longTable, key=TRUE), 3)

## ----echo=TRUE----------------------------------------------------------------
assays <- assays(longTable)
assays[[1]]

## ----echo=TRUE----------------------------------------------------------------
assays[[2]]

## ----echo=TRUE----------------------------------------------------------------
assays <- assays(longTable, withDimnames=TRUE)
colnames(assays[[1]])

## ----echo=TRUE----------------------------------------------------------------
assays <- assays(longTable, withDimnames=TRUE, metadata=TRUE)
colnames(assays[[2]])

## ----echo=TRUE----------------------------------------------------------------
assayNames(longTable)

## ----echo=TRUE----------------------------------------------------------------
colnames(assay(longTable, 'viability'))
assay(longTable, 'viability')

## ----echo=TRUE----------------------------------------------------------------
colnames(assay(longTable, 'viability', withDimnames=TRUE))
assay(longTable, 'viability', withDimnames=TRUE)

